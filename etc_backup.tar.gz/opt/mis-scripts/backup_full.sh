#!/bin/bash

# Función de ayuda que describe cómo usar el script
mensaje_de_ayuda() {
    echo "Uso: $0 [/opt/mis-sceripts/backup_full.sh] [/var/log /backup_dir/]"
    echo "$0 sirve para realizar un backup de los directorios seleccionados."
    echo "ARGUMENTOS:"
    echo "  [/opt/mis-sceripts/backup_full.sh]: Directorio a copiar"
    echo "  [/var/log /backup_dir/]: Dirección donde se guarda el backup"
    echo "Opciones: "
    echo "  -h: Mostrar ayuda"
}

# Comprueba si se ingresó el parámetro -h
if [ "$#" -eq 1 ] && [ "$1" == "-h" ]; then
    mensaje_de_ayuda  # Llama a la función de ayuda
    exit 0  # Sale del script con código 0 (indica éxito)
fi

# Comprueba si están los 2 argumentos
if [ "$#" -ne 2 ]; then
    echo "Error: se necesitan 2 argumentos."  # Mensaje de error si no se cumplen las condiciones
    mensaje_de_ayuda  # Muestra la ayuda
    exit 1  # Sale del script con código 1 (indica error)
fi

origen="$1"   # Asigna el primer argumento a la variable origen (directorio a respaldar)
destino="$2"  # Asigna el segundo argumento a la variable destino (donde guardar el backup)

# Busca si el argumento destino está montado
if ! mountpoint -q "$destino"; then
    echo "Error: '$destino' no está montado."  # Mensaje de error si no está montado
    exit 1  # Sale del script con código 1 (indica error)
fi

# Verifica si el origen es un punto de montaje o parte del sistema raíz
if mountpoint -q "$origen"; then
    if ! mountpoint -q "$origen"; then
        echo "Error: '$origen' no está montado."  # Mensaje de error si no está montado
        exit 1  # Sale del script con código 1 (indica error)
    fi
else 
    if [ ! -d "$origen" ]; then   # Si no es un punto de montaje, verifica que exista como directorio
        echo "Error: '$origen' no existe o no es un directorio válido."  
        exit 1  
    fi  
fi  

# Guardamos la fecha en una variable con el formato YYYYMMDD
fecha=$(date +%Y%m%d)  # Captura la fecha actual en el formato especificado

# Crear el nombre del archivo de backup usando basename para obtener solo el nombre del directorio origen
nombre_backup="$(basename "$origen")_bkp_$fecha.tar.gz"  

# tar = comando para comprimir archivos
tar -czf "$destino/$nombre_backup" -C "$origen" .  
# -c: crea un nuevo archivo .tar 
# -z: comprime el archivo a .gz 
# -f: especifica el nombre del archivo a crear 
# -C: cambia al directorio origen antes de empaquetar 

# Comprobar si tar se ejecutó correctamente
if [ $? -eq 0 ]; then   # $? = código de salida del último comando ejecutado (tar)
    echo "Backup realizado exitosamente: $destino/$nombre_backup"
else  
    echo "Error al realizar el backup."  
fi  
